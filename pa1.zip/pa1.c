#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "shell_array.h"
#include "shell_list.h"

static void destruct_list(Node *list);

int main(int argc, char** argv) {
    if (argc != 4) {
        return EXIT_FAILURE;
    }

    if (strcmp(argv[1], "-a") == 0) {
        int size;
        long* array = Array_Load_From_File(argv[2], &size);
        if (array == NULL) {
            return EXIT_FAILURE;
        }

        long n_comp = 0;
        Array_Shellsort(array, size, &n_comp);

        printf("%ld\n", n_comp);

        // for (int i = 0; i < size; i++) {
        //     printf("%ld ", array[i]);
        // }
        // printf("\n");

        if (Array_Save_To_File(argv[3], array, size) == 0) {
            free(array);
            return EXIT_FAILURE;
        }

        free(array);
        return EXIT_SUCCESS;
    }

    if (strcmp(argv[1], "-l") == 0) {
        
        Node* head = List_Load_From_File(argv[2]);
        if (head == NULL) {
            return EXIT_FAILURE;
        }

        long n_comp = 0;
        head = List_Shellsort(head, &n_comp);

        printf("%ld\n", n_comp);

        if (List_Save_To_File(argv[3], head) == 0) {
            destruct_list(head);
            return EXIT_FAILURE;
        }

        destruct_list(head);
        return EXIT_SUCCESS;
    }

    return EXIT_FAILURE;
}

static void destruct_list(Node *list)
{
    while (list != NULL)
    {
        Node* last_list = list;
        list = list -> next;
        free(last_list);
    }
}
