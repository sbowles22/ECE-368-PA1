#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "shell_array.h"
#include "sequence.h"

static void k_sort(long *array, int size, long *n_comp, int k);
static void swap(long *a, long *b, long *n_comp);

long *Array_Load_From_File(char *filename, int *size)
{
    *size = 0;

    FILE *f;
    f = fopen(filename, "r");
    if (f == NULL)
        return NULL;

    fseek(f, 0, SEEK_END);
    *size = ftell(f) / sizeof(long);

    long *arr = malloc(sizeof(long) * (*size));
    if (arr == NULL)
    {
        fclose(f);
        return NULL;
    }

    fseek(f, 0, SEEK_SET);
    fread(arr, sizeof(long), *size, f);

    fclose(f);
    return arr;
}

int Array_Save_To_File(char *filename, long *array, int size)
{
    FILE *f;
    f = fopen(filename, "wb");
    if (f == NULL)
        return 0;

    if (size != fwrite(array, sizeof(long), size, f))
    {   
        fclose(f);
        return 0;
    }

    fclose(f);
    return 1;
}

void Array_Shellsort(long *array, int size, long *n_comp)
{
    int seq_size;
    long *offsets = Generate_2p3q_Seq(size, &seq_size);

    int i;
    for (i = seq_size - 1; i >= 0; i--)
    { // Iterate through sequence
        // printf("K: %ld\n", offsets[i]);
        k_sort(array, size, n_comp, offsets[i]);
    }
    
    free(offsets);
}

static void k_sort(long *array, int size, long *n_comp, int k)
{
    int i;
    int j;
    int offset;
    bool sorted;
    for (offset = 0; offset < k; offset++)
    {
        for (i = offset; i < size; i += k)
        {
            sorted = true;
            for (j = i + k; j < size; j += k)
            {
                if (array[j-k] > array[j]) {
                    sorted = false;
                    swap(array + j, array + j - k, n_comp);
                }
            }

            if (sorted) {
                break;
            } 
        }
    }
}

static void swap(long *a, long *b, long *n_comp)
{
    *n_comp += 1;
    long temp;
    temp = *a;
    *a = *b;
    *b = temp;
}



    //     sorted = true;
    //     for (i = 0; i < size; i++)
    //     {
    //         for (j = size - 1 - k + offset; j >= i; j -= k)
    //         {
    //             if (array[j] > array[j + k])
    //             {
    //                 sorted = false;
    //                 swap(&array[j], &array[j + 1], n_comp);
    //             }
    //         }

    //         if (sorted) {
    //             printf("sorted triggered: %d\n", i);
    //             break;
    //         }
    //         sorted = true;
    //     }
    // }