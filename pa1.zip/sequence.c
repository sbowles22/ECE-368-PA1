#include <stdlib.h>
#include <stdio.h>
#include "sequence.h"

static void sort_sequence(long* sequence, int seq_size);
// static void find_sequence_2s(int n, int current_number, int current_row, int current_column, int seq_size, int* seq_index, long* sequence);
// static void find_sequence_3s(int n, int current_number, int current_row, int current_column, int seq_size, int* seq_index, long* sequence);
// static void find_sequence_length_2s(int n, int current_number, int current_row, int current_column, int* seq_size);
// static void find_sequence_length_3s(int n, int current_number, int current_row, int current_column, int* seq_size);

long *Generate_2p3q_Seq(int n, int *seq_size) {
    *seq_size = 0;

    if (n <= 1) return malloc(0);

    for (int current_row_left_number = 1; current_row_left_number < n; current_row_left_number *= 2) {
        for (int current_number = current_row_left_number; current_number < n; current_number *= 3) {
            *seq_size += 1;
        }
    }

    // find_sequence_length_2s(n, 1, 0, 0, seq_size);

    // printf("%d\n", *seq_size);

    long* sequence = malloc(sizeof(long) * (*seq_size));
    if (sequence == NULL) {
        *seq_size = 0;
        return NULL;
    }

    int seq_index = 0;
    for (int current_row_left_number = 1; current_row_left_number < n; current_row_left_number *= 2) {
        for (int current_number = current_row_left_number; current_number < n; current_number *= 3) {
            sequence[seq_index++] = current_number;
        }
    }
    
    // for (int i = 0; i < *seq_size; i++) {
    //     printf("%d\n", sequence[i]);
    // }
    
    sort_sequence(sequence, *seq_size);

    // for (int i = 0; i < *seq_size; i++) {
    //     printf("%d\n", sequence[i]);
    // }

    return sequence;
}

// static long pow(int a, int b) {
//     long c = 1;
//     for (int i = 0; i < b; i++) {
//         c *= a;
//     }
//     return c;
// }

static void sort_sequence(long* sequence, int seq_size) {
    int i;
    int j;
    long temp;
    int sentinel = 0;
    for (i = 0; i < seq_size; i++) {
        for (j = seq_size - 2; j >= i; j--) {
            if (sequence[j] > sequence[j+1]) {
                sentinel = 1;
                temp = sequence[j+1];
                sequence[j+1] = sequence[j];
                sequence[j] = temp;
            }
        }    

        if (!sentinel) return;
        sentinel = 0;
    }
}

// static void find_sequence_2s(int n, int current_number, int current_row, int current_column, int seq_size, int* seq_index, long* sequence) {
//     sequence[(*seq_index)++] = current_number;
    
//     if (2 * current_number >= n) {
//         return;
//     } else {
//         find_sequence_2s(n, 2 * current_number, current_row + 1, current_column, seq_size, seq_index, sequence);
//     }

//     if (current_column + 1 >= current_row || 3 * current_number >= n) {
//         return;
//     } else {
//         find_sequence_3s(n, 3 * current_number, current_row, current_column + 1, seq_size, seq_index, sequence);
//     }
// }

// static void find_sequence_3s(int n, int current_number, int current_row, int current_column, int seq_size, int* seq_index, long* sequence) {
//     sequence[(*seq_index)++] = current_number;

//     if (current_column + 1 >= current_row || 3 * current_number >= n) {
//         return;
//     } else {
//         find_sequence_3s(n, 3 * current_number, current_row, current_column + 1, seq_size, seq_index, sequence);
//     }
// }

// static void find_sequence_length_2s(int n, int current_number, int current_row, int current_column, int* seq_size) {
//     *seq_size += 1;
    
//     if (2 * current_number >= n) {
//         return;
//     } else {
//         find_sequence_length_2s(n, 2 * current_number, current_row + 1, current_column, seq_size);
//     }

//     if (current_column + 1 >= current_row || 3 * current_number >= n) {
//         return;
//     } else {
//         find_sequence_length_3s(n, 3 * current_number, current_row, current_column + 1, seq_size);
//     }
// }

// static void find_sequence_length_3s(int n, int current_number, int current_row, int current_column, int* seq_size) {
//     *seq_size += 1;

//     if (current_column + 1 >= current_row || 3 * current_number >= n) {
//         return;
//     } else {
//         find_sequence_length_3s(n, 3 * current_number, current_row, current_column + 1, seq_size);
//     }
// }
