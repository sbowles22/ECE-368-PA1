#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "shell_list.h"
#include "sequence.h"

static void destruct_list(Node *list);
static Node* k_sort_list(Node *list, long *n_comp, int k);
static void swap_list(Node **p1, Node **q1, Node **p2, Node **q2, Node** head, long *n_comp);
// static void print_list(Node *list);

Node *List_Load_From_File(char *filename)
{
    int size = 0;

    FILE *f;
    f = fopen(filename, "r");
    if (f == NULL)
        return NULL;

    fseek(f, 0, SEEK_END);
    size = ftell(f) / sizeof(long);
    fseek(f, 0, SEEK_SET);

    Node *head = NULL;
    Node *p = NULL;
    Node *q = NULL;
    for (int i = 0; i < size; i++)
    {
        q = malloc(sizeof(Node));
        if (q == NULL)
        {
            destruct_list(head);
            return NULL;
        }
        q->next = NULL;

        // For setting head on the first iteration
        if (head == NULL)
            head = q;

        // Get one long from binary file
        fread(&(q->value), sizeof(long), 1, f);

        if (p != NULL)
            p->next = q;
        p = q;
    }

    fclose(f);
    return head;
}

int List_Save_To_File(char *filename, Node *list)
{
    FILE *f;
    f = fopen(filename, "wb");
    if (f == NULL)
        return 0;

    while (list != NULL)
    {
        fwrite(&(list->value), sizeof(long), 1, f);
        list = list->next;
    }

    fclose(f);
    return 1;
}

Node *List_Shellsort(Node *list, long *n_comp)
{
    if (list == NULL)
        return NULL;

    int size = 0;
    Node *q = list;
    while ((q = q->next) != NULL)
        size++;

    int seq_size;
    long *offsets = Generate_2p3q_Seq(size, &seq_size);

    int i;
    for (i = seq_size - 1; i >= 0; i--)
    { // Iterate through sequence
        // printf("K: %ld\n", offsets[i]);
        list = k_sort_list(list, n_comp, offsets[i]);
    }

    free(offsets);
    return list;
}

static Node* k_sort_list(Node *list, long *n_comp, int k)
{
    int i;
    int offset;
    
    bool unsorted = true;
    
    // int *unsorteds = malloc(sizeof(int) * k);
    // int *changed_last_pass = malloc(sizeof(int) * k);
    // int *dones = calloc(k, sizeof(int));

    Node *p1;
    Node *q1;
    Node *p2;
    Node *q2;

    // for (i = 0; i < k; i++)
    // {
    //     unsorteds[i] = true;
    // }

    while (unsorted)
    {
        // for (i = 0; i < k; i++)
        // {
        //     printf("%d", unsorteds[i]);
        // }
        // printf("\n");
        // for (i = 0; i < k; i++)
        // {
        //     printf("%d", dones[i]);
        // }
        // printf("\n");

        // Initialize sentinels
        unsorted = false;

        // Initialize pointers
        p1 = NULL;
        q1 = list;
        p2 = NULL;
        q2 = list;

        // printf("BEGGINING: ");
        // print_list(list);
        // Shift second node pointers k ahead
        for (i = 0; i < k; i++)
        {
            p2 = q2;
            q2 = q2->next;
        }
        // printf("TRANSFER: ");
        // print_list(list);

        offset = 0;
        while (q2 != NULL)
        {
            // if (unsorteds[offset])
            // {
                if (q1->value > q2->value)
                {
                    // print_list(list);
                    unsorted = true;
                    // changed_last_pass[offset] = true;
                    swap_list(&p1, &q1, &p2, &q2, &list, n_comp);
                    // print_list(list);
                    // print_list(list);
                }
            // }

            offset++;
            offset %= k;

            p1 = q1;
            q1 = q1->next;
            p2 = q2;
            q2 = q2->next;

            // printf(".%p", q2);
        }

        // for (i = 0; i < k; i++)
        // {
        //     unsorteds[i] = changed_last_pass[i];
        // }
    }

    // print_list(list);

    // free(unsorteds);
    // free(changed_last_pass);
    // free(dones);
    return list;
}

static void swap_list(Node **p1, Node **q1, Node **p2, Node **q2, Node **head, long *n_comp)
{
    // printf("%p, %p, %p, %p, %p\n", *p1, *q1, *p2, *q2, *head);
    // if (p1 != NULL)
    //     printf("%p, %p, %p, %p\n", (*p1)->next, (*q1)->next, (*p2)->next, (*q2)->next);
    *n_comp += 1;

    if (*p1 == NULL) {
        // printf("HEAD CHANGE\n");   
        *head = *q2;
    }

    if ((*q1)->next != *q2)
    {
        // printf("BEFORE: ");
        // print_list(*head);

        if (*p1 != NULL)
        {
            (*p1)->next = *q2;
        }

        // printf("AFTER: ");
        // print_list(*head);

        (*p2)->next = *q1;

        Node *next_temp = (*q1)->next;

        (*q1)->next = (*q2)->next;
        (*q2)->next = next_temp;
    }
    else
    {
        if (*p1 != NULL) (*p1)->next = *q2;
        (*q1)->next = (*q2)->next;
        (*q2)->next = *q1;
    }

    Node *temp_q = *q1;
    *q1 = *q2;
    *q2 = temp_q;

    // if (p1 != NULL)
    //     printf("%p, %p, %p, %p\n", (*p1)->next, (*q1)->next, (*p2)->next, (*q2)->next);
}

static void destruct_list(Node *list)
{
    while (list != NULL)
    {
        Node* last_list = list;
        list = list -> next;
        free(last_list);
    }
}

// static void print_list(Node *list)
// {
//     while (list != NULL)
//     {
//         printf("%ld ", list->value);
//         list = list->next;
//     }
//     printf("\n");
// }
